package com.isep.controller;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isep.bean.BMessage;
import com.isep.bdd.Personne;
import com.isep.bean.BPersonne;
import com.isep.bdd.Message;
import com.isep.bean.BSujet;
import com.isep.bdd.GererMessage;
import com.isep.bdd.GererSujet;

/**
 * Servlet implementation class ChercherMessage
 */
@WebServlet("/ChercherMessage")
public class ChercherMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChercherMessage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//vérifie la connexion
				//if connecté {
					//récupère l'id du destinataire
					String id_sujet= request.getParameter("id");
					int id = Integer.parseInt(id_sujet);

					
					//récupère la liste des sujets correspondants
					Message message = new Message();
					Personne personne= new Personne();
					List<BMessage> listeMessage = new ArrayList<BMessage>();
					
					//id de l'expéditeur pour la conversation
					int id_exp=message.recupIdExp(id);
					listeMessage = message.recupMessage(id,id_exp);
					
					
					//stocke le resultat dans la variable de requete
					request.setAttribute("listeM", listeMessage);
					//recup des infos sur tous les utilisateurs
					List<BPersonne> Expediteur = personne.listerPersonne();
					request.setAttribute("expediteur", Expediteur);
					
					
					
					 this.getServletContext().getRequestDispatcher("/ListeMessage.jsp").forward(request, response);
				//}

				//else {
				//String Erreur = "Vous devez vous connecter";
				//RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/Accueil.jsp");
				//dispatcher.include(request, response);
			//}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
