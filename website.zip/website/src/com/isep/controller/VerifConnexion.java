package com.isep.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isep.bdd.*;
import com.isep.bean.*;


/**
 * Servlet implementation class VerifConnexion
 */
@WebServlet("/VerifConnexion")
public class VerifConnexion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VerifConnexion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		//if connecté 
		//id de l'article pour le nom du sujet
		String sujet=request.getParameter("id"); 
		int id = Integer.parseInt(sujet);
		
		//Autre a = new Autre();
		//Article article=new Article();
		
		/*String nomSujet = a.recupNomArticle(id);
		int idVendeur = a.recupIdVendeur(id);
		article.setNom(nomSujet);
		article.setIdPersonne(idVendeur);
		
		request.setAttribute("article", article);*/
		
		//récup des infos sur tous les utilisateurs
		GererMessage g = new GererMessage();
		Personne Destinataire = g.recupNomPersonne(id);
		request.setAttribute("destinataire", Destinataire);
		
		String nomArticle = g.recupNomArticle(id);
		request.setAttribute("article", nomArticle);
		
		RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/EnvoyerMessage.jsp");
		dispatcher.include(request, response);
		
		//else 
		//String Erreur = "Vous devez vous connecter";
		//RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/Article.jsp");
		//dispatcher.include(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
