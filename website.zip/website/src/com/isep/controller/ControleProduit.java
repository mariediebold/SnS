package com.isep.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isep.bdd.Article;

import com.isep.bean.BArticle;
import com.isep.bean.BPersonne;


/**
 * Servlet implementation class ControleProduit
 */
@WebServlet("/ControleProduit")
public class ControleProduit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControleProduit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
	    if(request.getParameter("id")!=null && request.getParameter("type")!=null) 
	    {
	    	
	    	String id=request.getParameter("id");
	    	String type=request.getParameter("type");
	    	request.setAttribute("article1", AffichageArticle(Integer.parseInt(id),type));
	    	this.getServletContext().getRequestDispatcher("/shop.jsp").forward(request, response);
	    	//RequestDispatcher dispatcher1=getServletContext().getRequestDispatcher("/shop.jsp");
	    	//dispatcher1.include(request, response);
	    }
		
		
		request.setAttribute("article1", AffichageArticle());
	     
		RequestDispatcher dispatcher1=getServletContext().getRequestDispatcher("/shop.jsp");
    	dispatcher1.include(request, response);	
    	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	
	private List<BArticle> AffichageArticle()
	     {//fonction permettant de recuperer tous les articles
		Article listeArticle=new Article();
		return listeArticle.recupArticle();
         }
	
	private List<BArticle> AffichageArticle(int id,String type)
    {//fonction permettant de recuperer en fonction de l'id,et du  type
	Article listeArticle=new Article();
	List<BArticle> liste=new ArrayList<BArticle>();
	for(int i=0;i<listeArticle.recupArticle().size();i++) {
		if (listeArticle.recupArticle().get(i).getId_categorie().equals(String.valueOf((id))) && listeArticle.recupArticle().get(i).getBloque().equals(type))
		{
			 
	         liste.add(listeArticle.recupArticle().get(i));
	   }
		
	
	}
	return liste;
    }

}
