package com.isep.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.isep.bdd.Personne;
import com.isep.bean.BPersonne;


/**
 * Servlet implementation class Inscription
 */
@WebServlet("/Inscription")
public class Inscription extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Inscription() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
	if (request.getParameter("mdp")!=null)
	{
		String mdp=request.getParameter("mdp");
    	String nom=request.getParameter("nom");
    	String prenom=request.getParameter("prenom");
    	String mail=request.getParameter("mail");
    	
    	Personne personne = new Personne();
    	personne.ajouterPersonne(nom,prenom,mail,mdp); //ajout d une personne a � la base dedonnee
    	RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/fashe-colorlib/connexion.jsp");
        dispatcher.include(request, response);
		
	}
	
  if (request.getParameter("mdp1")!=null)
	{
		String mdp=request.getParameter("mdp1");
    	
    	String mail=request.getParameter("mail1");
    	
    	Personne personne = new Personne();
    	
    	List<BPersonne> listePersonne = new ArrayList<BPersonne>();
    	listePersonne=personne.listerPersonne();
    
		for (int i=0;i<listePersonne.size();i++)
    	{
    	
    		if (mail.equals(listePersonne.get(i).getMail())) 
    		{
    			if (listePersonne.get(i).getMdp().equals(mdp))
    			{
    				HttpSession s = request.getSession();
    				s.setAttribute("id", listePersonne.get(i).getId());
    				s.setAttribute("prenom",listePersonne.get(i).getPrenom());
    				s.setAttribute("type", listePersonne.get(i).getType());
    				System.out.println(s.getAttribute("type"));
    				RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/accueil.jsp");
    		        dispatcher.include(request, response);
    		    }
    			else {
    				System.out.println(mail+listePersonne.get(i).getMail());
    			}
    			
    	}
    		else {
				System.out.println(mail+listePersonne.get(i).getMail());
				
				
			}
    		
    	}
    	
    	
		
	}
	
	}

	private boolean Connexion(String mdp,String mail,List<BPersonne> listePersonne) {
		boolean a=false;
		for (int i=0;i<listePersonne.size();i++)
    	{
    	
    		if (mail.equals(listePersonne.get(i).getMail())) 
    		{
    			if (listePersonne.get(i).getMdp().equals(mdp))
    			{
    				a=true;
    		    }
    			else {
    				a=false;
    			}
    			
    	}
    		else {
				System.out.println(mail+listePersonne.get(i).getMail());
				a=false;
				
			}
    		
    	}
		return a;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
