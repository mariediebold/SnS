package com.isep.controller;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isep.bdd.*;
import com.isep.bean.*;
/**
 * Servlet implementation class Supprimer
 */
@WebServlet("/Supprimer")
public class Supprimer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Supprimer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	
		
		if (request.getParameter("suj")!=null && request.getParameter("mess")==null) {
			String sujet = request.getParameter("suj");
			int id_suj = Integer.parseInt(sujet);
			
			GererSujet gs = new GererSujet();
			//suppression du sujet
			gs.supprSujet(id_suj);
		}
		else if(request.getParameter("suj")==null && request.getParameter("mess")!=null) {
			String message = request.getParameter("mess");
			int id_mess = Integer.parseInt(message);
			
			GererMessage gm = new GererMessage();
			//suppression du message
			gm.supprMessage(id_mess);
		}
		
		RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/Accueil.jsp");
		dispatcher.include(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
