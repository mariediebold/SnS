package com.isep.controller;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isep.*;
import com.isep.bdd.Message;
import com.isep.bdd.Personne;
import com.isep.bdd.Sujet;
import com.isep.bean.BArticle;
import com.isep.bean.BMessage;
import com.isep.bean.BPersonne;
import com.isep.bean.BSujet;

/**
 * Servlet implementation class ControleFoire
 */
@WebServlet("/ControleFoire")
public class ControleFoire extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControleFoire() {
        super();
     
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		// response.setContentType("text/css");
		 if (request.getParameter("idpersonnefoire")!=null) {
	        	String question =request.getParameter("question");
	        	String idpersonnefoire=request.getParameter("idpersonnefoire");   
	        	Sujet sujet=new Sujet();//ajout d'un message a � la base de donnee
	        	sujet.ajouterSujet(question,idpersonnefoire);
	        	request.setAttribute("sujet", AffichageSujet());
	    		request.setAttribute("message", AffichageMessage());
	    		request.setAttribute("personne", AffichagePersonne());
	        	RequestDispatcher dispatcher1=getServletContext().getRequestDispatcher("/foire.jsp");
		        dispatcher1.include(request, response);
		        }
		 else if (request.getParameter("texte")!=null) {
        	String texte =request.getParameter("texte");
        	String idpersonne=request.getParameter("idpersonne");
        	String idsujet=request.getParameter("idsujet");   
        	Message message=new Message();//ajout d'un message a � la base de donnee
        	message.ajouterMessage(texte,idpersonne,idsujet);
        	request.setAttribute("sujet", AffichageSujet());
    		request.setAttribute("message", AffichageMessage());
    		request.setAttribute("personne", AffichagePersonne());
        	RequestDispatcher dispatcher1=getServletContext().getRequestDispatcher("/foire.jsp");
	        dispatcher1.include(request, response);
	        }
        else {
        	request.setAttribute("sujet", AffichageSujet());
    		request.setAttribute("message", AffichageMessage());
    		request.setAttribute("personne", AffichagePersonne());
    		//RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/fashe-colorlib/foire.jsp");
           // dispatcher.include(request, response);
    	
            this.getServletContext().getRequestDispatcher("/foire.jsp").forward(request, response);
        }
   
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

	public List<BMessage> AffichageMessage(int id) {//fonction permettant de recuperer les messages en fonction des id des sujets
		Message listeMessage=new Message();
		return listeMessage.recupererMessage(id);
	
         }
	
	public List<BMessage> AffichageMessage() {//fonction permettant de recuperer tous les messages
		Message listeMessage=new Message();
		return listeMessage.recupererMessage();
	
         }
	
	private List<BSujet> AffichageSujet() {//fonction permettant de recuperer tous les sujets
		Sujet listeSujet=new Sujet();
		return listeSujet.listerSujet();
         }
	private List<BPersonne> AffichagePersonne() {//fonction permettant de recuperer tous les pers
		Personne listePersonne=new Personne();
		return listePersonne.listerPersonne();
         }

}
