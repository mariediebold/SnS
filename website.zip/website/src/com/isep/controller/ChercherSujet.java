package com.isep.controller;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isep.bean.*;
import com.isep.bdd.*;


/**
 * Servlet implementation class chercherSujet
 */
@WebServlet("/chercherSujet")
public class ChercherSujet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChercherSujet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//vérifie la connexion
		//if connecté {
			//récupère l'id du destinataire (session)
			//String id_dest= request.getParameter("id");
			//int id = Integer.parseInt(id_dest);
			int id=1;
			
			//récupère la liste des sujets correspondants
			GererSujet gestionSujet = new GererSujet();
			List<Sujet> listeSujet = new ArrayList<Sujet>();
			listeSujet = gestionSujet.recupSujet(id);
			
			//stocke le résultat dans la variable de requête
			request.setAttribute("liste", listeSujet);
			//récup des infos sur tous les utilisateurs
			Personne personne = new Personne();
			List<BPersonne> Expediteur = personne.listerPersonne();
			request.setAttribute("expediteur", Expediteur);
			
			 this.getServletContext().getRequestDispatcher("/ListeSujet.jsp").forward(request, response);
		//}

		//else {
		//String Erreur = "Vous devez vous connecter";
		//RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/Accueil.jsp");
		//dispatcher.include(request, response);
	//}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
