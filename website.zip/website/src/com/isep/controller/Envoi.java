package com.isep.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.isep.bdd.*;
import com.isep.bean.*;

/**
 * Servlet implementation class Envoi
 */
@WebServlet("/Envoi")
public class Envoi extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Envoi() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getParameter("nomSujet")!=null && request.getParameter("texte")!=null && request.getParameter("destinataire")!=null){ 
			response.setContentType("text/html");
			//PrintWriter out = response.getWriter();
			
			
			String iddest = request.getParameter("destinataire");
			String nomSujet = request.getParameter("nomSujet");
			String texte = request.getParameter("texte");
		
			
			Sujet sujet = new Sujet();
			Message gestionMess = new Message();
			//id de l'expediteur (à recup sur la session)
			int expediteur = 1; //session
			
			if (sujet.existenceSujet(iddest,nomSujet).size()!=0)  {
								
				Message newMessage = new Message();
				
				gestionMess.ajouterMessage(texte, String.valueOf(expediteur),String.valueOf(sujet.existenceSujet(iddest, nomSujet).get(0).getId()));
				request.setAttribute("nouveauMessage", newMessage);
				
				
			}
			else {
								
				//ajout du sujet dans la bdd
				sujet.ajouterSujet(nomSujet, iddest);
				request.setAttribute("nouveauSujet", sujet.existenceSujet(iddest, nomSujet).get(0));
				
				//ajout du message dans la bdd
				gestionMess.ajouterMessage(texte, String.valueOf(expediteur),String.valueOf(sujet.existenceSujet(iddest, nomSujet).get(0).getId()));
				
				request.setAttribute("nouveauMessage", gestionMess.existenceMessage(texte, expediteur,sujet.existenceSujet(iddest, nomSujet).get(0).getId()));
				
			}
					}
		this.getServletContext().getRequestDispatcher("/Article.jsp?statut=ok").forward(request, response);

			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
