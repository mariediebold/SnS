package com.isep.bdd;

import java.util.ArrayList;
import java.util.HashMap;

import java.util.List;

import com.isep.bean.BCategorie;
import com.isep.bean.BSscategorie;

import java.sql.Connection;  

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.sql.Statement;

public class Categorie {

	  private Connection connexion;
       
	  public List<BSscategorie> recupererSscategorie(int idcat){
		  
	        List<BSscategorie> listeSscategorie = new ArrayList<BSscategorie>();
	        Statement statement = null;
	        ResultSet resultat = null;
	        ResultSet resultat1 = null;
	       connexion=null;
	     
	        loadDatabase();
	        
	        try {
	            statement = connexion.createStatement();

	               PreparedStatement rechercheSscategorie = connexion.prepareStatement("SELECT * FROM sscategorie WHERE id_categorie=? ");
	               rechercheSscategorie.setInt(1,idcat);
	               resultat = rechercheSscategorie.executeQuery();
	              //resultat= statement.executeQuery("SELECT * FROM sscategorie WHERE id_categorie=1"); 

	            // R�cup�ration des donn�es
	            while (resultat.next()) { // permet d aller a la ligne suivante
	                Integer id = resultat.getInt("id");
	                String nom = resultat.getString("nom");
	                BSscategorie sscategorie = new BSscategorie();
	                
	                sscategorie.setId(id);
	                sscategorie.setNom(nom);
	        
	                listeSscategorie.add(sscategorie);
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	        return listeSscategorie;
		  
	  }
	  
	 
	    public List<BCategorie> recupererCategorie() {
	    	
	        List<BCategorie> listeCategorie = new ArrayList<BCategorie>();
	        Statement statement = null;
	        ResultSet resultat = null;
	       connexion=null;
	     
	        loadDatabase();
	        
	        try {
	            statement = connexion.createStatement();

	            // Ex�cution de la requ�te
	            resultat = statement.executeQuery("SELECT * FROM categorie");

	            // R�cup�ration des donn�es
	            while (resultat.next()) { // permet d aller a la ligne suivante
	                Integer id = resultat.getInt("id");
	                String nom = resultat.getString("nom");
	                BCategorie categorie = new BCategorie();
	                categorie.setId(id);
	                categorie.setNom(nom);
	                categorie.setSscategorie(recupererSscategorie(id));
	                listeCategorie.add(categorie);
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	        return listeCategorie;
	    }
	    
	    private void loadDatabase() {
	        try {
	        	Class.forName("com.mysql.jdbc.Driver");
	          } 
	        catch (ClassNotFoundException e) {
	        	e.printStackTrace();
	        }

	        try {
	            connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/site", "root", "");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
}
