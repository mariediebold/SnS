package com.isep.bdd;

import java.sql.Date;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.isep.bean.BMessage;
import com.isep.bean.BPersonne;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import beans.Article;
import beans.Message;
import beans.Personne;
import beans.Sujet;


public class GererMessage {

	
	private Connection connexion;

	private void loadDatabase() {
	    // Chargement du driver
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	    } catch (ClassNotFoundException e) {
	    }
	
	    try {
	        connexion = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/site", "root", "");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	   
    
    public void ajoutMessage(BMessage newMessage) {
        loadDatabase();
        
        try {
            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("INSERT INTO message(id_personne,texte,date,id_sujet) VALUES(?, ?, ?, ?);");
            preparedStatement.setInt(1, newMessage.getId_personne());
            preparedStatement.setString(2, newMessage.getTexte());
            preparedStatement.setTimestamp(3, newMessage.getDateJour());
            preparedStatement.setInt(4, newMessage.getIdSujet());
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void supprMessage(int id) {
        loadDatabase();
         
        try {
            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("DELETE FROM message WHERE id=?;");
            preparedStatement.setInt(1, id);
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
   
		 public int  recupIdExp(int id_sujet) {
		        int idExp = 0;
		        Statement statement = null;
		        ResultSet resultat = null;
		        //int destinataire = newSujet.getIdDestinataire();
				//String nomSujet = newSujet.getNom();
				//Date dateJour = newSujet.getDateJour();
		        
		        loadDatabase();
		        
		        try {
		            statement = (Statement) connexion.createStatement();

		            // Exécution de la requête
		            //resultat = statement.executeQuery("SELECT id FROM sujet WHERE nom=? AND id_personne=? AND date=?;"); //requêtes préparées
		            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT id_personne FROM message WHERE id_sujet=? ;");
		            preparedStatement.setInt(1, id_sujet);
		            //preparedStatement.setDate(3, newSujet.getDateJour());
		            
		            resultat = preparedStatement.executeQuery();
		            // Récupération des données
		            while (resultat.next()) {
		                int id_Exp = resultat.getInt("id_personne");
		                idExp = id_Exp;
		            }
		        } catch (SQLException e) {
		        } finally {
		            // Fermeture de la connexion
		            try {
		                if (resultat != null)
		                    resultat.close();
		                if (statement != null)
		                    statement.close();
		                if (connexion != null)
		                    connexion.close();
		            } catch (SQLException ignore) {
		            }
		        }
		        
		        return idExp;
		    }
    		    
		
		 public List<BPersonne> recupPersonne() {
			 	List<BPersonne> listePersonne = new ArrayList<BPersonne>();
		        //GererSujet g = new GererSujet();
		        //String nome=g.recupNomSujet(id_sujet);
		        Statement statement = null;
		        ResultSet resultat = null;

		        loadDatabase();
		        
		        try {
		            statement = (Statement) connexion.createStatement();

		            // Exécution de la requête
		            //resultat = statement.executeQuery("SELECT nom,date FROM sujet WHERE id_personne = ?;");
		            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT id,nom,prenom,mail,mpd FROM personne;");
		            

		            resultat = preparedStatement.executeQuery();
		            // Récupération des données
		            while (resultat.next()) {
		            	int id=resultat.getInt("id");
		               	String nom = resultat.getString("nom");
		               	String prenom = resultat.getString("prenom");
		               	String mail = resultat.getString("mail");
		               	String mdp = resultat.getString("mpd");
		                
		               	BPersonne personne = new BPersonne();
		               	personne.setId(id); 
		               	personne.setNom(nom);
		               	personne.setPrenom(prenom);
		               	personne.setMail(mail);
		               	personne.setMdp(mdp);
		                  
		                listePersonne.add(personne);
		            }
		        } catch (SQLException e) {
		        } finally {
		            // Fermeture de la connexion
		            try {
		                if (resultat != null)
		                    resultat.close();
		                if (statement != null)
		                    statement.close();
		                if (connexion != null)
		                    connexion.close();
		            } catch (SQLException ignore) {
		            }
		        }
		        
		        return listePersonne;
		    }
		 
		 
		 public String recupNomArticle(int id) {
		        String NomArticle = null;
		        Statement statement = null;
		        ResultSet resultat = null;
		        //int destinataire = newSujet.getIdDestinataire();
				//String nomSujet = newSujet.getNom();
				//Date dateJour = newSujet.getDateJour();
		        
		        loadDatabase();
		        
		        try {
		            statement = (Statement) connexion.createStatement();

		            // Exécution de la requête
		            //resultat = statement.executeQuery("SELECT id FROM sujet WHERE nom=? AND id_personne=? AND date=?;"); //requêtes préparées
		            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT nom FROM article WHERE id=?;");
		            preparedStatement.setInt(1, id);
		            //preparedStatement.setDate(3, newSujet.getDateJour());
		            
		            resultat = preparedStatement.executeQuery();
		            // Récupération des données
		            while (resultat.next()) {
		                String nom = resultat.getString("nom");
		                NomArticle=nom;
		                
		            }
		        } catch (SQLException e) {
		        } finally {
		            // Fermeture de la connexion
		            try {
		                if (resultat != null)
		                    resultat.close();
		                if (statement != null)
		                    statement.close();
		                if (connexion != null)
		                    connexion.close();
		            } catch (SQLException ignore) {
		            }
		        }
		        
		        return NomArticle;
		    }
		    
		 
		 public Personne recupNomPersonne(int id) {
			   	Personne p = new Personne();
		        Statement statement = null;
		        ResultSet resultat = null;
		        //int destinataire = newSujet.getIdDestinataire();
				//String nomSujet = newSujet.getNom();
				//Date dateJour = newSujet.getDateJour();
		        
		        loadDatabase();
		        
		        try {
		            statement = (Statement) connexion.createStatement();

		            // Exécution de la requête
		            //resultat = statement.executeQuery("SELECT id FROM sujet WHERE nom=? AND id_personne=? AND date=?;"); //requêtes préparées
		            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT personne.id,personne.nom,personne.prenom FROM personne JOIN article ON personne.id=article.id_personne WHERE article.id=?;");
		            preparedStatement.setInt(1, id);
		            //preparedStatement.setDate(3, newSujet.getDateJour());
		            
		            resultat = preparedStatement.executeQuery();
		            // Récupération des données
		            while (resultat.next()) {
		            	int id_personne = resultat.getInt("id");
		                String nom = resultat.getString("nom");
		                String prenom = resultat.getString("prenom");
   
		                p.setId(id_personne);
		                p.setNom(nom);
		                p.setPrenom(prenom);

		                
		            }
		        } catch (SQLException e) {
		        } finally {
		            // Fermeture de la connexion
		            try {
		                if (resultat != null)
		                    resultat.close();
		                if (statement != null)
		                    statement.close();
		                if (connexion != null)
		                    connexion.close();
		            } catch (SQLException ignore) {
		            }
		        }
		        
		        return p;
		    }
		 
    
    public List<Message> recupMessage(int id_sujet,int id_personne) {
        List<Message> listeMessage = new ArrayList<Message>();
        GererSujet g = new GererSujet();
        String nome=g.recupNomSujet(id_sujet);
        Statement statement = null;
        ResultSet resultat = null;

        loadDatabase();
        
        try {
            statement = (Statement) connexion.createStatement();

            // Exécution de la requête
            //resultat = statement.executeQuery("SELECT nom,date FROM sujet WHERE id_personne = ?;");
            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT id,id_personne,texte,date FROM message WHERE id_sujet = ? UNION SELECT id,id_personne,texte,date FROM message WHERE (id_personne=? AND id_sujet IN (SELECT id FROM sujet WHERE nom=? AND id_personne=?)) ORDER by date asc;");
            preparedStatement.setInt(1, id_sujet);
            preparedStatement.setInt(2, 1 ); //id de la session
            preparedStatement.setString(3, nome );
            preparedStatement.setInt(4, id_personne);  //id de la personne à qui on a envoyé un message

            resultat = preparedStatement.executeQuery();
            // Récupération des données
            while (resultat.next()) {
                int id_expediteur = resultat.getInt("id_personne");
            	String texte = resultat.getString("texte");
            	Timestamp dateMessage = resultat.getTimestamp("date");
            	int id=resultat.getInt("id");
                
                Message message = new Message();
                message.setIdExpediteur(id_expediteur);
                message.setTexte(texte);
                message.setDateJour(dateMessage);
                message.setId(id);
                
                listeMessage.add(message);
            }
        } catch (SQLException e) {
        } finally {
            // Fermeture de la connexion
            try {
                if (resultat != null)
                    resultat.close();
                if (statement != null)
                    statement.close();
                if (connexion != null)
                    connexion.close();
            } catch (SQLException ignore) {
            }
        }
        
        return listeMessage;
    }
    
   
    
    
}