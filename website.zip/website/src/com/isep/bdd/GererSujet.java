package com.isep.bdd;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import beans.Sujet;


public class GererSujet {
	
	private Connection connexion;

	private void loadDatabase() {
	    // Chargement du driver
	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	    } catch (ClassNotFoundException e) {
	    }
	
	    try {
	        connexion = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/site", "root", "");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
    
    public int recupId(Sujet newSujet) {
        int idSujets = 0;
        Statement statement = null;
        ResultSet resultat = null;
        //int destinataire = newSujet.getIdDestinataire();
		//String nomSujet = newSujet.getNom();
		//Date dateJour = newSujet.getDateJour();
        
        loadDatabase();
        
        try {
            statement = (Statement) connexion.createStatement();

            // Exécution de la requête
            //resultat = statement.executeQuery("SELECT id FROM sujet WHERE nom=? AND id_personne=? AND date=?;"); //requêtes préparées
            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT id FROM sujet WHERE nom=? AND id_personne=? ;");
            preparedStatement.setString(1, newSujet.getNom());
            preparedStatement.setInt(2, newSujet.getIdDestinataire());
            //preparedStatement.setDate(3, newSujet.getDateJour());
            
            resultat = preparedStatement.executeQuery();
            // Récupération des données
            while (resultat.next()) {
                int id_sujet = resultat.getInt("id");
                idSujets = id_sujet;
            }
        } catch (SQLException e) {
        } finally {
            // Fermeture de la connexion
            try {
                if (resultat != null)
                    resultat.close();
                if (statement != null)
                    statement.close();
                if (connexion != null)
                    connexion.close();
            } catch (SQLException ignore) {
            }
        }
        
        return idSujets;
    }
    
    
    public String recupNomSujet(int id_sujet) {
        String NomSuj = null;
        Statement statement = null;
        ResultSet resultat = null;
        //int destinataire = newSujet.getIdDestinataire();
		//String nomSujet = newSujet.getNom();
		//Date dateJour = newSujet.getDateJour();
        
        loadDatabase();
        
        try {
            statement = (Statement) connexion.createStatement();

            // Exécution de la requête
            //resultat = statement.executeQuery("SELECT id FROM sujet WHERE nom=? AND id_personne=? AND date=?;"); //requêtes préparées
            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT nom FROM sujet WHERE id=? ;");
            preparedStatement.setInt(1, id_sujet);
            //preparedStatement.setDate(3, newSujet.getDateJour());
            
            resultat = preparedStatement.executeQuery();
            // Récupération des données
            while (resultat.next()) {
                String nom_sujet = resultat.getString("nom");
                NomSuj=nom_sujet;
                
            }
        } catch (SQLException e) {
        } finally {
            // Fermeture de la connexion
            try {
                if (resultat != null)
                    resultat.close();
                if (statement != null)
                    statement.close();
                if (connexion != null)
                    connexion.close();
            } catch (SQLException ignore) {
            }
        }
        
        return NomSuj;
    }
    
    
    public boolean existenceSujet(Sujet newSujet) {
    	boolean Existe=false;
    	Statement statement = null;
        ResultSet resultat = null;
        
        loadDatabase();
        
        try {
        	
            statement = (Statement) connexion.createStatement();
    	
            resultat = statement.executeQuery("SELECT nom,id_personne FROM sujet");
           
            while (resultat.next()) {
             String nom = resultat.getString("nom");
             int id_personne = resultat.getInt("id_personne");
             if (nom.equalsIgnoreCase(newSujet.getNom()) && id_personne==newSujet.getIdDestinataire()) {
            	Existe=true;
             }
            
         }
     } catch (SQLException e) {
     } finally {
         // Fermeture de la connexion
         try {
             if (resultat != null)
                 resultat.close();
             if (statement != null)
                 statement.close();
             if (connexion != null)
                 connexion.close();
         } catch (SQLException ignore) {
         }
     }
        return Existe;
    }
    
    
    public void ajoutSujet(Sujet newSujet) {
        loadDatabase();
         
        try {
            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("INSERT INTO sujet(nom, date, id_personne) VALUES(?, ?, ?);");
            preparedStatement.setString(1, newSujet.getNom());
            preparedStatement.setTimestamp(2, newSujet.getDateJour());
            preparedStatement.setInt(3, newSujet.getIdDestinataire());
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public void supprSujet(int id) {
        loadDatabase();
         
        try {
            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("DELETE FROM sujet WHERE id=?;");
            preparedStatement.setInt(1, id);
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public List<Sujet> recupSujet(int id_destinataire) {
        List<Sujet> listeSujet = new ArrayList<Sujet>();
        Statement statement = null;
        ResultSet resultat = null;

        loadDatabase();
        
        try {
            statement = (Statement) connexion.createStatement();

            // Exécution de la requête
            //resultat = statement.executeQuery("SELECT nom,date FROM sujet WHERE id_personne = ?;");
            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT id,nom,date,id_personne FROM sujet WHERE id_personne = ?;");
            preparedStatement.setInt(1, id_destinataire);

            resultat = preparedStatement.executeQuery();
            // Récupération des données
            while (resultat.next()) {
            	//int id_dest= resultat.getInt("id_personne");
                String nom = resultat.getString("nom");
                Timestamp dateSujet = resultat.getTimestamp("date");
                int id= resultat.getInt("id");
                int id_personne= resultat.getInt("id_personne");
                
                Sujet sujet = new Sujet();
               // sujet.setIdDestinataire(id_dest);
                sujet.setNom(nom);
                sujet.setDateJour(dateSujet);
                sujet.setId(id);
                sujet.setIdDestinataire(id_personne);
                
                listeSujet.add(sujet);
            }
        } catch (SQLException e) {
        } finally {
            // Fermeture de la connexion
            try {
                if (resultat != null)
                    resultat.close();
                if (statement != null)
                    statement.close();
                if (connexion != null)
                    connexion.close();
            } catch (SQLException ignore) {
            }
        }
        
        return listeSujet;
    }
    
    
}
