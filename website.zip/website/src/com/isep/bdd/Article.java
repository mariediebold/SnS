package com.isep.bdd;

import java.sql.Connection;



import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.isep.bean.BArticle;
import com.isep.bean.BCategorie;
import com.isep.bean.BSscategorie;

public class Article {
	  private Connection connexion;
      
	 
	 
	    public List<BArticle> recupArticle() {
	    	
	        List<BArticle> listeArticle = new ArrayList<BArticle>();
	        Statement statement = null;
	        ResultSet resultat = null;
	       connexion=null;
	     
	        loadDatabase();
	        
	        try {
	            statement = connexion.createStatement();

	            // Ex�cution de la requ�te
	            resultat = statement.executeQuery("SELECT * FROM article");

	            // R�cup�ration des donn�es
	            while (resultat.next()) { // permet d aller a la ligne suivante
	                Integer idpers = resultat.getInt("id_personne");
	                String nom = resultat.getString("nom");
	                String image= resultat.getString("image");
	                Integer idcat = resultat.getInt("id_categorie");
	                Integer idsscat = resultat.getInt("id_sscategorie");
	                Integer bloque= resultat.getInt("bloque");
	                Integer prix= resultat.getInt("prix");
	                
	                
	                BArticle article = new BArticle();
	                article.setNom(nom);
	                article.setId_categorie(String.valueOf(idcat));
	                article.setId_personne(String.valueOf(idpers));
	                article.setId_sscategorie(String.valueOf(idsscat));
	                article.setBloque(String.valueOf(bloque));
	                article.setPrix(String.valueOf(prix));
	                article.setImage(image);
	                
	
	                listeArticle.add(article);
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	        return listeArticle;
	    }
	    
  @SuppressWarnings("null")
public List<BArticle> nouvauteArticle() {
	    	
	        List<BArticle> listeArticle = new ArrayList<BArticle>();
	        Statement statement = null;
	        ResultSet resultat = null;
	       connexion=null;
	     
	        loadDatabase();
	        
	        try {
	            statement = connexion.createStatement();

	            // Ex�cution de la requ�te
	            PreparedStatement preparedStatement = connexion.prepareStatement("SELECT * FROM article  ");
	           
	            preparedStatement.executeUpdate();
	            
	            // R�cup�ration des donn�es
	            while (resultat.next()) { // permet d aller a la ligne suivante
	                Integer idpers = resultat.getInt("id_personne");
	                String nom = resultat.getString("nom");
	                String image= resultat.getString("image");
	                Integer idcat = resultat.getInt("id_categorie");
	                Integer idsscat = resultat.getInt("id_sscategorie");
	                Integer bloque= resultat.getInt("bloque");
	                Integer prix= resultat.getInt("prix");
	                
	                
	                BArticle article = new BArticle();
	                article.setNom(nom);
	                article.setId_categorie(String.valueOf(idcat));
	                article.setId_personne(String.valueOf(idpers));
	                article.setId_sscategorie(String.valueOf(idsscat));
	                article.setBloque(String.valueOf(bloque));
	                article.setPrix(String.valueOf(prix));
	                article.setImage(image);
	                
	
	                listeArticle.add(article);
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	        return listeArticle;
	    }
	    
	    
	    private void loadDatabase() {
	        try {
	        	Class.forName("com.mysql.jdbc.Driver");
	          } 
	        catch (ClassNotFoundException e) {
	        	e.printStackTrace();
	        }

	        try {
	            connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/site", "root", "");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

		   public void ajouterArticle(BArticle article) {
		        loadDatabase();
		        System.out.println(article.getId_categorie());
		        try {
		            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO article(nom, id_categorie, id_sscategorie,id_personne, bloque,image,prix) VALUES (?,?,?,?,?,?,?)");
		            preparedStatement.setString(1,article.getNom());
		            preparedStatement.setInt(2,Integer.parseInt(article.getId_categorie()));
		            preparedStatement.setInt(3,Integer.parseInt(article.getId_sscategorie()));
		            preparedStatement.setInt(4,Integer.parseInt(article.getId_personne()));
		            preparedStatement.setInt(5,Integer.parseInt(article.getBloque()));
		            preparedStatement.setString(6,article.getImage());
		            preparedStatement.setInt(7,Integer.parseInt(article.getPrix()));
		            preparedStatement.executeUpdate();
		            
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
		    }

		public Connection getConnexion() {
			return connexion;
		}

		public void setConnexion(Connection connexion) {
			this.connexion = connexion;
		}  

}
