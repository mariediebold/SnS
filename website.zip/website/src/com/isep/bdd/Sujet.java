package com.isep.bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.isep.bean.BMessage;
import com.isep.bean.BSujet;

public class Sujet {
	private Connection connexion;
    
	  public List<BSujet> listerSujet(){
		  
	        List<BSujet> listeSujet = new ArrayList<BSujet>();
	        Statement statement = null;
	        ResultSet resultat = null;
	        ResultSet resultat1 = null;
	       connexion=null;
	     
	        loadDatabase();
	        
	        try {
	            statement = connexion.createStatement();

	            resultat = statement.executeQuery("SELECT * FROM sujet");
	              

	            // R�cup�ration des donn�es
	            while (resultat.next()) { // permet d aller a la ligne suivante
	                Integer id = resultat.getInt("id");
	                Integer idpers = resultat.getInt("id_personne");
	                String nom = resultat.getString("nom");
	                
	                BSujet sujet = new BSujet();
	                sujet.setId(id);
	                sujet.setId_personne(idpers);
	                sujet.setNom(nom);
	               
	        
	              
					listeSujet.add(sujet);
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	    
	        return listeSujet;
		  
	  }
	  
	    
	    private void loadDatabase() {
	        try {
	        	Class.forName("com.mysql.jdbc.Driver");
	          } 
	        catch (ClassNotFoundException e) {
	        	e.printStackTrace();
	        }

	        try {
	            connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/site", "root", "");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public void ajouterSujet(String nom, String idpersonne) {
			loadDatabase();
	       
	        try {
	            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO sujet(nom,id_personne,date) VALUES (?,?,NOW())");
	            preparedStatement.setString(1,nom);
	            preparedStatement.setInt(2,Integer.parseInt(idpersonne));
	           
	            preparedStatement.executeUpdate();
	            
	        } catch (SQLException e) {
	            e.printStackTrace();
	        
	    }  
	    }
	    
 public List<BSujet> existenceSujet(String id, String nomsujet) { // verifie l'existence d'un sujet
	       List<BSujet> listeSujet = new ArrayList<BSujet>();
	    	Statement statement = null;
	        ResultSet resultat = null;
	        
	        loadDatabase();
	        
	        try {
	        	
	            statement = (Statement) connexion.createStatement();
	    	
	            resultat = statement.executeQuery("SELECT id,nom,id_personne FROM sujet");
	           
	            while (resultat.next()) {
	            	 String nom = resultat.getString("nom");
	            	 Integer id_personne=resultat.getInt("id_personne");
	            	 Integer idsujet = resultat.getInt("id");
	             if (nom.equalsIgnoreCase(nomsujet) && id_personne==Integer.parseInt(id) ) {
	            	   
		                BSujet sujet = new BSujet();
		                sujet.setId_personne(id_personne);
		                 sujet.setId(idsujet);
		                sujet.setNom(nom);
		                listeSujet.add(sujet);
		               
	             }
	            
	         }
	     } catch (SQLException e) {
	     } finally {
	         // Fermeture de la connexion
	         try {
	             if (resultat != null)
	                 resultat.close();
	             if (statement != null)
	                 statement.close();
	             if (connexion != null)
	                 connexion.close();
	         } catch (SQLException ignore) {
	         }
	     }
	        return listeSujet;
	    }
	    
 public List<Integer> recupId(String id_personne,String nomsujet) {
	 List<Integer> id = new ArrayList<Integer>();
     Statement statement = null;
     ResultSet resultat = null;
    
     loadDatabase();
     
     try {
         statement = (Statement) connexion.createStatement();

         PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT id FROM sujet WHERE nom=? AND id_personne=? ");
         preparedStatement.setString(1, nomsujet);
         preparedStatement.setInt(2, Integer.parseInt(id_personne));
        
         
         resultat = preparedStatement.executeQuery();
         // Recuperation des donnees
         while (resultat.next()) {
             int id_sujet = resultat.getInt("id");
             id.add(id_sujet);
         }
     } catch (SQLException e) {
     } finally {
         // Fermeture de la connexion
         try {
             if (resultat != null)
                 resultat.close();
             if (statement != null)
                 statement.close();
             if (connexion != null)
                 connexion.close();
         } catch (SQLException ignore) {
         }
     }
     
     return id;
 }
 
	    
}
