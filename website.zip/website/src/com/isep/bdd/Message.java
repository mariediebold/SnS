package com.isep.bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


import com.isep.bean.BMessage;


public class Message {
	private Connection connexion;
    
	  public List<BMessage> recupererMessage(int id){
		  
	        List<BMessage> listeMessage = new ArrayList<BMessage>();
	        Statement statement = null;
	        ResultSet resultat = null;
	        ResultSet resultat1 = null;
	       connexion=null;
	     
	        loadDatabase();
	        
	        try {
	            statement = connexion.createStatement();

	               PreparedStatement rechercheMessage = connexion.prepareStatement("SELECT * FROM message WHERE id_sujet=? ");
	               rechercheMessage.setInt(1,id);
	               resultat = rechercheMessage.executeQuery();
	              

	            // R�cup�ration des donn�es
	            while (resultat.next()) { // permet d aller a la ligne suivante
	                Integer idmessage = resultat.getInt("id");
	                Integer idpers = resultat.getInt("id_personne");
	                Integer idsujet = resultat.getInt("id_sujet");
	                String texte = resultat.getString("texte");
	                BMessage message = new BMessage();
	                message.setId(idmessage);
	                message.setId_personne(idpers);
	                message.setId_sujet(idsujet);
	                message.setTexte(texte);
	        
	                listeMessage.add(message);
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	        return listeMessage;
		  
	  }
	  
	  
	  public List<BMessage> recupererMessage(){
		  
	        List<BMessage> listeMessage = new ArrayList<BMessage>();
	        Statement statement = null;
	        ResultSet resultat = null;
	        ResultSet resultat1 = null;
	       connexion=null;
	     
	        loadDatabase();
	        
	        try {
	            statement = connexion.createStatement();
	            resultat = statement.executeQuery("SELECT * FROM message");
	            // R�cup�ration des donn�es
	            while (resultat.next()) { // permet d aller a la ligne suivante
	                Integer idmessage = resultat.getInt("id");
	                Integer idpers = resultat.getInt("id_personne");
	                Integer idsujet = resultat.getInt("id_sujet");
	                String texte = resultat.getString("texte");
	                BMessage message = new BMessage();
	                message.setId(idmessage);
	                message.setId_personne(idpers);
	                message.setId_sujet(idsujet);
	                message.setTexte(texte);
	        
	                listeMessage.add(message);
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	        return listeMessage;
		  
	  }
	    private void loadDatabase() {
	        try {
	        	Class.forName("com.mysql.jdbc.Driver");
	          } 
	        catch (ClassNotFoundException e) {
	        	e.printStackTrace();
	        }

	        try {
	            connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/site", "root", "");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }


		public void ajouterMessage(String texte, String idpersonne, String idsujet) {
			loadDatabase();
	       
	        try {
	            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO message(texte, id_personne, id_sujet,date) VALUES (?,?,?,NOW())");
	            preparedStatement.setString(1,texte);
	            preparedStatement.setInt(2,Integer.parseInt(idpersonne));
	            preparedStatement.setInt(3,Integer.parseInt(idsujet));
	           
	            preparedStatement.executeUpdate();
	            
	        } catch (SQLException e) {
	            e.printStackTrace();
	        
	    }  
			
		}
		
		 public int  recupIdExp(int id_sujet) { //recuperer l'id d un exp a partir de lid du sujet du message
		        int idExp = 0;
		        Statement statement = null;
		        ResultSet resultat = null;
		        //int destinataire = newSujet.getIdDestinataire();
				//String nomSujet = newSujet.getNom();
				//Date dateJour = newSujet.getDateJour();
		        
		        loadDatabase();
		        
		        try {
		            statement = (Statement) connexion.createStatement();

		            // Exécution de la requête
		            //resultat = statement.executeQuery("SELECT id FROM sujet WHERE nom=? AND id_personne=? AND date=?;"); //requêtes préparées
		            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT id_personne FROM message WHERE id_sujet=? ;");
		            preparedStatement.setInt(1, id_sujet);
		            //preparedStatement.setDate(3, newSujet.getDateJour());
		            
		            resultat = preparedStatement.executeQuery();
		            // Récupération des données
		            while (resultat.next()) {
		                int id_Exp = resultat.getInt("id_personne");
		                idExp = id_Exp;
		            }
		        } catch (SQLException e) {
		        } finally {
		            // Fermeture de la connexion
		            try {
		                if (resultat != null)
		                    resultat.close();
		                if (statement != null)
		                    statement.close();
		                if (connexion != null)
		                    connexion.close();
		            } catch (SQLException ignore) {
		            }
		        }
		        
		        return idExp;
		    }
		 
		    public List<BMessage> recupMessage(int id_sujet,int id_personne) {
		        List<BMessage> listeMessage = new ArrayList<BMessage>();
		        GererSujet g = new GererSujet();
		        String nomsujet=g.recupNomSujet(id_sujet);
		        Statement statement = null;
		        ResultSet resultat = null;

		        loadDatabase();
		        
		        try {
		            statement = (Statement) connexion.createStatement();

		            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT id,id_personne,texte,date FROM message WHERE id_sujet = ? UNION SELECT id,id_personne,texte,date FROM message WHERE (id_personne=? AND id_sujet IN (SELECT id FROM sujet WHERE nom=? AND id_personne=?)) ORDER by date asc;");
		            preparedStatement.setInt(1, id_sujet);
		            preparedStatement.setInt(2, 1 ); //id de la session
		            preparedStatement.setString(3, nomsujet );
		            preparedStatement.setInt(4, id_personne);  //id de la personne à qui on a envoyé un message

		            resultat = preparedStatement.executeQuery();
		            while (resultat.next()) {
		                int id_expediteur = resultat.getInt("id_personne");
		            	String texte = resultat.getString("texte");
		            	int id=resultat.getInt("id");
		                
		                BMessage message = new BMessage();
		                message.setId_personne(id_expediteur);
		                message.setTexte(texte);
		                message.setId(id);
		                message.setId_sujet(id_sujet);
		                listeMessage.add(message);
		            }
		        } catch (SQLException e) {
		        } finally {
		            // Fermeture de la connexion
		            try {
		                if (resultat != null)
		                    resultat.close();
		                if (statement != null)
		                    statement.close();
		                if (connexion != null)
		                    connexion.close();
		            } catch (SQLException ignore) {
		            }
		        }
		        
		        return listeMessage;
		    }


			public List<BMessage> existenceMessage(String texte, int expediteur, int idsujet) {
				 List<BMessage> monmessage = new ArrayList<BMessage>();
			     Statement statement = null;
			     ResultSet resultat = null;
			    
			     loadDatabase();
			     
			     try {
			         statement = (Statement) connexion.createStatement();

			         PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT * FROM sujet WHERE id_sujet=? AND texte=? AND id_personne=? ");
			         preparedStatement.setString(2, texte);
			         preparedStatement.setInt(1, idsujet);
			         preparedStatement.setInt(3, expediteur);
			         resultat = preparedStatement.executeQuery();
			         // Recuperation des donnees
			         while (resultat.next()) {
			        	    
			            	int id=resultat.getInt("id");
			                
			                BMessage message = new BMessage();
			                message.setId_personne(expediteur);
			                message.setTexte(texte);
			                message.setId(id);
			                message.setId_sujet(idsujet);
			                monmessage.add(message);
			         }
			     } catch (SQLException e) {
			     } finally {
			         // Fermeture de la connexion
			         try {
			             if (resultat != null)
			                 resultat.close();
			             if (statement != null)
			                 statement.close();
			             if (connexion != null)
			                 connexion.close();
			         } catch (SQLException ignore) {
			         }
			     }
			     
			     return monmessage;
			 }
}
