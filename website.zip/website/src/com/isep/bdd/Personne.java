package com.isep.bdd;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.isep.bean.BArticle;
import com.isep.bean.BPersonne;
import com.isep.bean.BSujet;

public class Personne {

	  private Connection connexion;
      
	  public List<BPersonne> listerPersonne(){
		  
	        List<BPersonne> listePersonne = new ArrayList<BPersonne>();
	        Statement statement = null;
	        ResultSet resultat = null;
	       
	       connexion=null;
	     
	        loadDatabase();
	        
	        try {
	            statement = connexion.createStatement();

	            resultat = statement.executeQuery("SELECT * FROM personne");
	              

	            // R�cup�ration des donn�es
	            while (resultat.next()) { // permet d aller a la ligne suivante
	                Integer id = resultat.getInt("id");
	                Integer type = resultat.getInt("type");
	                String nom = resultat.getString("nom");
	                String prenom = resultat.getString("prenom");
	                String mdp = resultat.getString("mpd");
	                String mail = resultat.getString("mail");
	                
	                BPersonne sujet = new BPersonne();
	                sujet.setId(id);
	                sujet.setMail(mail);
	                sujet.setMdp(mdp);
	                sujet.setPrenom(prenom);
	                sujet.setType(type);
	                sujet.setNom(nom);
	               
	           
					listePersonne.add(sujet);
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	        
	        return listePersonne;
		  
	  }
	  
	    
	    private void loadDatabase() {
	        try {
	        	Class.forName("com.mysql.jdbc.Driver");
	          } 
	        catch (ClassNotFoundException e) {
	        	e.printStackTrace();
	        }

	        try {
	            connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/site", "root", "");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

   
		public void ajouterPersonne(String nom, String prenom, String mail, String mdp) {
			loadDatabase();
		       
	        try {
	            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO personne(nom,prenom,mail,mpd,type) VALUES (?,?,?,?,1)");
	            preparedStatement.setString(1,nom);
	            preparedStatement.setString(2,prenom);
	            preparedStatement.setString(3,mail);
	            preparedStatement.setString(4,mdp);
	            
	            preparedStatement.executeUpdate();
	            
	        } catch (SQLException e) {
	            e.printStackTrace();
	        
	    }  
			
		}
		
		
		public BPersonne recupNomPersonne(int idr) {
			BPersonne sujet = new BPersonne();
	        Statement statement = null;
	        ResultSet resultat = null; 
	        loadDatabase();
	        
	        try {
	            statement = (Statement) connexion.createStatement();

	            // Exécution de la requête
	            //resultat = statement.executeQuery("SELECT id FROM sujet WHERE nom=? AND id_personne=? AND date=?;"); //requêtes préparées
	            PreparedStatement preparedStatement = (PreparedStatement) connexion.prepareStatement("SELECT personne.id,personne.nom,personne.prenom FROM personne JOIN article ON personne.id=article.id_personne WHERE article.id=?;");
	            preparedStatement.setInt(1, idr);
	            
	            
	            resultat = preparedStatement.executeQuery();
	            // Récupération des données
	            while (resultat.next()) {
	            	Integer id = resultat.getInt("id");
	                Integer type = resultat.getInt("type");
	                String nom = resultat.getString("nom");
	                String prenom = resultat.getString("prenom");
	                String mdp = resultat.getString("mpd");
	                String mail = resultat.getString("mail");
	                
	               
	                sujet.setId(id);
	                sujet.setMail(mail);
	                sujet.setMdp(mdp);
	                sujet.setPrenom(prenom);
	                sujet.setType(type);
	                sujet.setNom(nom);

	                
	            }
	        } catch (SQLException e) {
	        } finally {
	            // Fermeture de la connexion
	            try {
	                if (resultat != null)
	                    resultat.close();
	                if (statement != null)
	                    statement.close();
	                if (connexion != null)
	                    connexion.close();
	            } catch (SQLException ignore) {
	            }
	        }
	        
	        return sujet;
	    }
	
}
