package com.isep.bean;

public class BArticle {

private String nom;
private String bloque;
private String id_sscategorie;
private String id_categorie;
private String id_personne;
private String image;
private String prix;

public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public String getBloque() {
	return bloque;
}
public void setBloque(String bloque) {
	this.bloque = bloque;
}
public String getId_sscategorie() {
	return id_sscategorie;
}
public void setId_sscategorie(String id_sscategorie) {
	this.id_sscategorie = id_sscategorie;
}
public String getId_categorie() {
	return id_categorie;
}
public void setId_categorie(String id_categorie) {
	this.id_categorie = id_categorie;
}
public String getId_personne() {
	return id_personne;
}
public void setId_personne(String id_personne) {
	this.id_personne = id_personne;
}
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}
public String getPrix() {
	return prix;
}
public void setPrix(String prix) {
	this.prix = prix;
}

}
