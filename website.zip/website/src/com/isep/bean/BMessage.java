package com.isep.bean;

public class BMessage {
	
private int id;
private String texte;
private int id_sujet;
private int id_personne;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTexte() {
	return texte;
}
public void setTexte(String texte) {
	this.texte = texte;
}
public int getId_sujet() {
	return id_sujet;
}
public void setId_sujet(int id_sujet) {
	this.id_sujet = id_sujet;
}
public int getId_personne() {
	return id_personne;
}
public void setId_personne(int id_personne) {
	this.id_personne = id_personne;
}


}
