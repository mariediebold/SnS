package com.isep.bean;
import java.util.HashMap;
import java.util.List;

public class BCategorie {
	private int id;
    private String nom;
   private List<BSscategorie> sscategorie;
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public List<BSscategorie> getSscategorie() {
		return sscategorie;
	}
	public void setSscategorie(List<BSscategorie> sscategorie) {
		this.sscategorie = sscategorie;
	}
	
    
}
